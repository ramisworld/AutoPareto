"""Pure stability policy for the one frozen search-time inference benchmark."""

from __future__ import annotations

from dataclasses import dataclass
import math
import statistics


PROTOCOL_VERSION = "autopareto_inference_stabilized_v4_aggregate4"


@dataclass(frozen=True)
class StabilityConfig:
    block_size: int = 5
    required_stable_blocks: int = 2
    max_warmup_blocks: int = 6
    median_tolerance: float = 0.02
    coefficient_variation_limit: float = 0.05
    measured_passes: int = 3
    repetitions_per_pass: int = 10


DEFAULT_STABILITY = StabilityConfig()


def coefficient_of_variation(values: list[float] | tuple[float, ...]) -> float:
    if not values:
        raise ValueError("stability requires at least one repetition")
    mean = statistics.fmean(values)
    if mean <= 0:
        return math.inf
    return statistics.pstdev(values) / mean


def median_relative_drift(previous: list[float], current: list[float]) -> float:
    if not previous or not current:
        raise ValueError("drift requires two non-empty blocks")
    old = statistics.median(previous)
    new = statistics.median(current)
    if old <= 0:
        return math.inf
    return abs(new - old) / old


def block_is_stable(previous: list[float], current: list[float], config=DEFAULT_STABILITY) -> bool:
    return (
        median_relative_drift(previous, current) <= config.median_tolerance
        and coefficient_of_variation(current) <= config.coefficient_variation_limit
    )


def adaptive_warmup(raw_blocks: list[list[float]], config=DEFAULT_STABILITY) -> dict[str, object]:
    """Find the first run of adjacent stable blocks, without model-specific tuning."""
    if len(raw_blocks) > config.max_warmup_blocks:
        raise ValueError("warm-up blocks exceed the frozen maximum")
    stable_flags = [
        block_is_stable(raw_blocks[i - 1], raw_blocks[i], config)
        for i in range(1, len(raw_blocks))
    ]
    run = 0
    start = None
    for index, stable in enumerate(stable_flags, start=1):
        run = run + 1 if stable else 0
        if run >= config.required_stable_blocks:
            start = index - config.required_stable_blocks + 1
            break
    return {
        "stable": start is not None,
        "stable_flags": stable_flags,
        "stable_start_block": start,
        "blocks_seen": len(raw_blocks),
        "max_warmup_blocks": config.max_warmup_blocks,
    }


def measured_pass_is_stable(repetitions: list[float], config=DEFAULT_STABILITY) -> bool:
    if len(repetitions) != config.repetitions_per_pass:
        return False
    if coefficient_of_variation(repetitions) > config.coefficient_variation_limit:
        return False
    if len(repetitions) != config.block_size * 2:
        return False
    return block_is_stable(repetitions[: config.block_size], repetitions[config.block_size :], config)


def accept_measurement(
    *,
    correctness_passed: bool,
    warmup_blocks: list[list[float]],
    measured_passes: list[list[float]],
    config=DEFAULT_STABILITY,
) -> dict[str, object]:
    warmup = adaptive_warmup(warmup_blocks, config)
    pass_flags = [measured_pass_is_stable(values, config) for values in measured_passes]
    stable = correctness_passed and bool(warmup["stable"]) and len(pass_flags) == config.measured_passes and all(pass_flags)
    all_repetitions = [value for values in measured_passes for value in values]
    return {
        "protocol_version": PROTOCOL_VERSION,
        "correctness_passed": correctness_passed,
        "warmup": warmup,
        "measured_pass_stable": pass_flags,
        "stable": stable,
        "cached_decode_tokens_per_second_median": statistics.median(all_repetitions) if stable else None,
        "coefficient_variation_all_repetitions": coefficient_of_variation(all_repetitions) if all_repetitions else None,
        "raw_repetitions": measured_passes,
    }
