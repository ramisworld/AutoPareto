"""Stable search-time inference benchmark interface.

The actual protected model adapter is supplied only inside a future isolated run.
This module provides the frozen protocol gate and a small CLI that never exposes the
historical legacy benchmark.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys
import time
import types
from typing import Any

from .benchmark_policy import DEFAULT_STABILITY, PROTOCOL_VERSION, accept_measurement
from .correctness_policy import (
    BF16_SCREEN_MEAN_ATOL,
    CHECKED_DECODE_STEPS,
    CORRECTNESS_RULE_VERSION,
    FP32_ADJUDICATION_MAX_ATOL,
    FP32_ADJUDICATION_MEAN_ATOL,
)


WORKLOAD = {
    "input_tokens": 256,
    "generated_tokens": 256,
    "decoding": "greedy",
    "precision": "bfloat16",
    "batch_size": 1,
    "independent_sequences_per_repetition": 4,
    "prefill_in_timing_region": False,
}

FIXED_INPUT_TEXT = (
    "AutoPareto fixed inference benchmark. The purpose of this input is to measure "
    "decoding throughput and CUDA memory under identical conditions. No generated "
    "text is scored for meaning, style, correctness, or safety. "
)


def _synchronize(torch_module: Any) -> None:
    torch_module.cuda.synchronize()


def _last_logits(logits: Any) -> Any:
    return logits[:, -1:, :]


def _inference_autocast(torch_module: Any) -> Any:
    """Use the frozen bf16 inference dtype used by the registered candidates."""
    return torch_module.amp.autocast(device_type="cuda", dtype=torch_module.bfloat16)


def correctness_gate(
    adapter: Any,
    uncached_forward: Any,
    input_ids: Any,
    torch_module: Any,
    decode_steps: int = 32,
    model: Any | None = None,
    fp32_model: Any | None = None,
    fp32_adapter: Any | None = None,
) -> dict[str, Any]:
    """Compare cached and uncached logits before any timing is accepted."""
    if model is not None:
        # Canonical candidates use the protected SDPA full-prefix reference so a
        # FlashAttention-vs-SDPA backend difference is not mistaken for a cache
        # error. Custom adapters retain the protected model-forward reference.
        from protected.inference_adapter import check_cached_correctness

        with torch_module.inference_mode(), _inference_autocast(torch_module):
            bf16_result = check_cached_correctness(
                model,
                adapter,
                input_ids,
                steps=decode_steps,
                mean_atol=BF16_SCREEN_MEAN_ATOL,
                raise_on_failure=False,
            )
        if not bf16_result["finite_outputs"] or not bf16_result["greedy_tokens_match"]:
            raise RuntimeError(
                "cached/full correctness failed: "
                f"finite_outputs={bf16_result['finite_outputs']} "
                f"greedy_tokens_match={bf16_result['greedy_tokens_match']} "
                f"max_mean_abs_error={bf16_result['max_mean_logit_absolute_error']:.6g} "
                f"max_abs_error={bf16_result['max_logit_absolute_error']:.6g}"
            )
        if fp32_model is None or fp32_adapter is None:
            raise RuntimeError("protected FP32 cache-correctness adjudication is unavailable")
        with torch_module.inference_mode(), torch_module.amp.autocast(device_type="cuda", enabled=False):
            fp32_result = check_cached_correctness(
                fp32_model,
                fp32_adapter,
                input_ids,
                steps=decode_steps,
                mean_atol=FP32_ADJUDICATION_MEAN_ATOL,
                max_atol=FP32_ADJUDICATION_MAX_ATOL,
                raise_on_failure=False,
            )
        if not fp32_result["passed"]:
            raise RuntimeError(
                "FP32 cached/full correctness adjudication failed: "
                f"finite_outputs={fp32_result['finite_outputs']} "
                f"greedy_tokens_match={fp32_result['greedy_tokens_match']} "
                f"max_mean_abs_error={fp32_result['max_mean_logit_absolute_error']:.6g} "
                f"max_abs_error={fp32_result['max_logit_absolute_error']:.6g}"
            )
        return {
            "passed": True,
            "verification_mode": CORRECTNESS_RULE_VERSION,
            "checked_decode_steps": decode_steps,
            "bf16_screen": bf16_result,
            "fp32_adjudication": fp32_result,
            "bf16_screen_mean_threshold": BF16_SCREEN_MEAN_ATOL,
            "fp32_adjudication_mean_threshold": FP32_ADJUDICATION_MEAN_ATOL,
            "fp32_adjudication_max_threshold": FP32_ADJUDICATION_MAX_ATOL,
        }

    with torch_module.inference_mode(), _inference_autocast(torch_module):
        uncached_logits = uncached_forward(input_ids)
        cached_logits, state = adapter.prefill(input_ids)
        torch_module.testing.assert_close(_last_logits(cached_logits), _last_logits(uncached_logits), rtol=0.0, atol=0.03)
        prefix = input_ids
        next_token = torch_module.argmax(_last_logits(uncached_logits), dim=-1)
        for _ in range(decode_steps):
            cached_logits, state = adapter.decode_one(next_token[:, -1:], state)
            prefix = torch_module.cat((prefix, next_token[:, -1:]), dim=1)
            uncached_logits = uncached_forward(prefix)
            torch_module.testing.assert_close(_last_logits(cached_logits), _last_logits(uncached_logits), rtol=0.0, atol=0.03)
            next_token = torch_module.argmax(_last_logits(uncached_logits), dim=-1)
    return {
        "passed": True,
        "greedy_tokens_match": True,
        "logits_match": True,
        "verification_mode": "legacy_generic_fallback",
        "checked_decode_steps": decode_steps,
    }


def timed_cached_decode(adapter: Any, input_ids: Any, torch_module: Any, generated_tokens: int = 256) -> dict[str, Any]:
    """One fixed-workload repetition; the caller owns warm-up and stability gates."""
    torch_module.cuda.reset_peak_memory_stats()
    with torch_module.inference_mode(), _inference_autocast(torch_module):
        _, state = adapter.prefill(input_ids)
        token = input_ids[:, -1:]
        _synchronize(torch_module)
        started = time.perf_counter()
        for _ in range(generated_tokens):
            logits, state = adapter.decode_one(token, state)
            token = torch_module.argmax(_last_logits(logits), dim=-1)
        _synchronize(torch_module)
        elapsed = time.perf_counter() - started
    if elapsed <= 0:
        raise RuntimeError("non-positive synchronized decode duration")
    return {
        "cached_decode_tokens_per_second": generated_tokens / elapsed,
        "allocated_cuda_memory_bytes": int(torch_module.cuda.max_memory_allocated()),
        "reserved_cuda_memory_bytes": int(torch_module.cuda.max_memory_reserved()),
        "kv_cache_bytes": int(_validated_cache_nbytes(adapter, state)),
        "elapsed_seconds": elapsed,
    }


def timed_aggregated_cached_decode(
    adapter: Any,
    input_ids: Any,
    torch_module: Any,
    generated_tokens: int = 256,
    sequence_count: int = 4,
) -> dict[str, Any]:
    """Time four independent batch-1 cached workloads as one protected repetition.

    All prefills are intentionally outside the decode timing region. Each workload
    has a fresh cache and is decoded for the same fixed number of greedy tokens.
    Host timing is authoritative; CUDA events are persisted as an independent
    timing diagnostic.
    """
    if sequence_count != 4:
        raise ValueError("the frozen aggregate protocol requires exactly four sequences")
    workloads = [input_ids.clone() for _ in range(sequence_count)]
    torch_module.cuda.reset_peak_memory_stats()
    with torch_module.inference_mode(), _inference_autocast(torch_module):
        states = []
        tokens = []
        for workload in workloads:
            _, state = adapter.prefill(workload)
            states.append(state)
            tokens.append(workload[:, -1:])
        _synchronize(torch_module)
        cuda_started = torch_module.cuda.Event(enable_timing=True)
        cuda_finished = torch_module.cuda.Event(enable_timing=True)
        cuda_started.record()
        started = time.perf_counter()
        for _ in range(generated_tokens):
            for index in range(sequence_count):
                logits, states[index] = adapter.decode_one(tokens[index], states[index])
                tokens[index] = torch_module.argmax(_last_logits(logits), dim=-1)
        cuda_finished.record()
        _synchronize(torch_module)
        elapsed = time.perf_counter() - started
        cuda_elapsed = float(cuda_started.elapsed_time(cuda_finished)) / 1000.0
    if elapsed <= 0 or cuda_elapsed <= 0:
        raise RuntimeError("non-positive synchronized aggregate decode duration")
    kv_bytes = sum(_validated_cache_nbytes(adapter, state) for state in states)
    return {
        "cached_decode_tokens_per_second": (generated_tokens * sequence_count) / elapsed,
        "allocated_cuda_memory_bytes": int(torch_module.cuda.max_memory_allocated()),
        "reserved_cuda_memory_bytes": int(torch_module.cuda.max_memory_reserved()),
        "kv_cache_bytes": int(kv_bytes),
        "kv_cache_bytes_per_sequence": [
            int(_validated_cache_nbytes(adapter, state)) for state in states
        ],
        "elapsed_seconds": elapsed,
        "cuda_event_elapsed_seconds": cuda_elapsed,
        "decoded_tokens": generated_tokens * sequence_count,
        "sequence_count": sequence_count,
        "prefill_in_timing_region": False,
    }


def run_stable_benchmark(
    adapter: Any,
    uncached_forward: Any,
    input_ids: Any,
    torch_module: Any,
    model: Any | None = None,
    fp32_model: Any | None = None,
    fp32_adapter: Any | None = None,
) -> dict[str, Any]:
    """Execute the frozen protocol for a supplied protected adapter.

    This function is intentionally not called by the Phase 0.5 CLI or tests.  It is
    the future protected evaluator entry point and keeps raw observations intact.
    """
    correctness = correctness_gate(
        adapter,
        uncached_forward,
        input_ids,
        torch_module,
        model=model,
        fp32_model=fp32_model,
        fp32_adapter=fp32_adapter,
    )
    warmup_blocks: list[list[float]] = []
    warmup_details: list[list[dict[str, Any]]] = []
    warmup_result = None
    for _ in range(DEFAULT_STABILITY.max_warmup_blocks):
        details = [timed_cached_decode(adapter, input_ids, torch_module, WORKLOAD["generated_tokens"]) for _ in range(DEFAULT_STABILITY.block_size)]
        warmup_details.append(details)
        warmup_blocks.append([float(item["cached_decode_tokens_per_second"]) for item in details])
        warmup_result = __import__("study.contracts_2026.benchmark_policy", fromlist=["adaptive_warmup"]).adaptive_warmup(warmup_blocks, DEFAULT_STABILITY)
        if warmup_result["stable"]:
            break
    if not warmup_result or not warmup_result["stable"]:
        all_warmup_details = [item for group in warmup_details for item in group]
        return {
            "protocol_version": PROTOCOL_VERSION,
            "status": "measurement-unstable",
            "inference_status": "unstable",
            "stable": False,
            "correctness_passed": True,
            "correctness": correctness,
            "warmup_blocks": warmup_details,
            "measured_passes": [],
            "allocated_cuda_memory_bytes": max(item["allocated_cuda_memory_bytes"] for item in all_warmup_details),
            "reserved_cuda_memory_bytes": max(item["reserved_cuda_memory_bytes"] for item in all_warmup_details),
            "kv_cache_bytes": max(item["kv_cache_bytes"] for item in all_warmup_details),
            "peak_allocated_inference_memory_bytes": max(item["allocated_cuda_memory_bytes"] for item in all_warmup_details),
            "synchronized_timing": True,
            "cache_correctness_gate": True,
            "same_workload_for_all_candidates": True,
        }
    measured_details = []
    measured_values = []
    for _ in range(DEFAULT_STABILITY.measured_passes):
        details = [timed_cached_decode(adapter, input_ids, torch_module, WORKLOAD["generated_tokens"]) for _ in range(DEFAULT_STABILITY.repetitions_per_pass)]
        measured_details.append(details)
        measured_values.append([float(item["cached_decode_tokens_per_second"]) for item in details])
    payload = {
        "correctness_passed": True,
        "correctness": correctness,
        "warmup_blocks": warmup_blocks,
        "measured_passes": measured_values,
        "allocated_cuda_memory_bytes": max(item["allocated_cuda_memory_bytes"] for group in measured_details for item in group),
        "reserved_cuda_memory_bytes": max(item["reserved_cuda_memory_bytes"] for group in measured_details for item in group),
        "kv_cache_bytes": max(item["kv_cache_bytes"] for group in measured_details for item in group),
    }
    result = finalize_payload(payload)
    result["warmup_raw_repetitions"] = warmup_details
    result["measured_raw_repetitions"] = measured_details
    result["workload"] = WORKLOAD
    return result


def run_aggregated_stable_benchmark(
    adapter: Any,
    uncached_forward: Any,
    input_ids: Any,
    torch_module: Any,
    model: Any | None = None,
    fp32_model: Any | None = None,
    fp32_adapter: Any | None = None,
) -> dict[str, Any]:
    """Run the frozen four-sequence search-time benchmark."""
    correctness = correctness_gate(
        adapter,
        uncached_forward,
        input_ids,
        torch_module,
        model=model,
        fp32_model=fp32_model,
        fp32_adapter=fp32_adapter,
    )
    warmup_blocks: list[list[float]] = []
    warmup_details: list[list[dict[str, Any]]] = []
    warmup_result = None
    for _ in range(DEFAULT_STABILITY.max_warmup_blocks):
        details = [
            timed_aggregated_cached_decode(
                adapter,
                input_ids,
                torch_module,
                WORKLOAD["generated_tokens"],
                WORKLOAD["independent_sequences_per_repetition"],
            )
            for _ in range(DEFAULT_STABILITY.block_size)
        ]
        warmup_details.append(details)
        warmup_blocks.append([float(item["cached_decode_tokens_per_second"]) for item in details])
        warmup_result = __import__("study.contracts_2026.benchmark_policy", fromlist=["adaptive_warmup"]).adaptive_warmup(
            warmup_blocks,
            DEFAULT_STABILITY,
        )
        if warmup_result["stable"]:
            break
    if not warmup_result or not warmup_result["stable"]:
        all_details = [item for group in warmup_details for item in group]
        return {
            "protocol_version": PROTOCOL_VERSION,
            "status": "measurement-unstable",
            "inference_status": "unstable",
            "stable": False,
            "correctness_passed": True,
            "correctness": correctness,
            "warmup_blocks": warmup_details,
            "measured_passes": [],
            "allocated_cuda_memory_bytes": max(item["allocated_cuda_memory_bytes"] for item in all_details),
            "reserved_cuda_memory_bytes": max(item["reserved_cuda_memory_bytes"] for item in all_details),
            "kv_cache_bytes": max(item["kv_cache_bytes"] for item in all_details),
            "peak_allocated_inference_memory_bytes": max(item["allocated_cuda_memory_bytes"] for item in all_details),
            "synchronized_timing": True,
            "cuda_event_timing_diagnostic": True,
            "cache_correctness_gate": True,
            "same_workload_for_all_candidates": True,
            "workload": WORKLOAD,
        }
    measured_details = []
    measured_values = []
    for _ in range(DEFAULT_STABILITY.measured_passes):
        details = [
            timed_aggregated_cached_decode(
                adapter,
                input_ids,
                torch_module,
                WORKLOAD["generated_tokens"],
                WORKLOAD["independent_sequences_per_repetition"],
            )
            for _ in range(DEFAULT_STABILITY.repetitions_per_pass)
        ]
        measured_details.append(details)
        measured_values.append([float(item["cached_decode_tokens_per_second"]) for item in details])
    payload = {
        "correctness_passed": True,
        "correctness": correctness,
        "warmup_blocks": warmup_blocks,
        "measured_passes": measured_values,
        "allocated_cuda_memory_bytes": max(
            item["allocated_cuda_memory_bytes"] for group in measured_details for item in group
        ),
        "reserved_cuda_memory_bytes": max(
            item["reserved_cuda_memory_bytes"] for group in measured_details for item in group
        ),
        "kv_cache_bytes": max(item["kv_cache_bytes"] for group in measured_details for item in group),
    }
    result = finalize_payload(payload)
    result["warmup_raw_repetitions"] = warmup_details
    result["measured_raw_repetitions"] = measured_details
    result["workload"] = WORKLOAD
    result["timing_boundary"] = {
        "prefill_excluded": True,
        "decode_loop_included": True,
        "synchronized_before_start": True,
        "synchronized_after_end": True,
        "authoritative_clock": "synchronized_host_perf_counter",
        "cuda_event_clock": "diagnostic_only",
    }
    return result


def validate_measurement_payload(payload: dict[str, Any]) -> None:
    required = {
        "correctness_passed",
        "warmup_blocks",
        "measured_passes",
        "allocated_cuda_memory_bytes",
        "reserved_cuda_memory_bytes",
        "kv_cache_bytes",
    }
    missing = sorted(required - payload.keys())
    if missing:
        raise ValueError(f"inference payload missing protected fields: {missing}")
    if "legacy" in json.dumps(payload, sort_keys=True).lower():
        raise ValueError("legacy benchmark payloads are not accepted by the study")


def finalize_payload(payload: dict[str, Any]) -> dict[str, Any]:
    validate_measurement_payload(payload)
    result = accept_measurement(
        correctness_passed=bool(payload["correctness_passed"]),
        warmup_blocks=payload["warmup_blocks"],
        measured_passes=payload["measured_passes"],
        config=DEFAULT_STABILITY,
    )
    result.update(
        {
            "status": "stable" if result["stable"] else "measurement-unstable",
            "inference_status": "stable" if result["stable"] else "unstable",
            "allocated_cuda_memory_bytes": int(payload["allocated_cuda_memory_bytes"]),
            "reserved_cuda_memory_bytes": int(payload["reserved_cuda_memory_bytes"]),
            "kv_cache_bytes": int(payload["kv_cache_bytes"]),
            "peak_allocated_inference_memory_bytes": int(payload["allocated_cuda_memory_bytes"]),
            "synchronized_timing": True,
            "cache_correctness_gate": True,
            "same_workload_for_all_candidates": True,
        }
    )
    if "correctness" in payload:
        result["correctness"] = payload["correctness"]
    return result


def _fixed_input(tokenizer: Any, torch_module: Any, device: Any) -> Any:
    seed_ids = tokenizer.encode(FIXED_INPUT_TEXT, prepend=tokenizer.get_bos_token_id())
    if not seed_ids:
        raise RuntimeError("protected inference text produced no tokens")
    count = int(WORKLOAD["input_tokens"])
    ids = (seed_ids * ((count + len(seed_ids) - 1) // len(seed_ids)))[:count]
    return torch_module.tensor([ids], dtype=torch_module.long, device=device)


def _validated_cache_nbytes(adapter: Any, state: Any) -> int:
    from protected.inference_adapter import validated_cache_nbytes

    return validated_cache_nbytes(adapter, state)


def _load_candidate_definitions(context: pathlib.Path, candidate: str) -> tuple[Any, Any]:
    train_path = (context / candidate).resolve()
    if train_path.parent != context.resolve() or train_path.name != "train.py" or not train_path.is_file() or train_path.is_symlink():
        raise RuntimeError("inference candidate must be the regular train.py in the isolated context")
    source = train_path.read_text()
    marker = "# Setup: tokenizer, model, optimizer, dataloader"
    if marker not in source:
        raise RuntimeError("candidate train.py removed the protected setup marker")
    module = types.ModuleType("autopareto_candidate_train")
    module.__file__ = str(train_path)
    # Dataclass and a few other standard-library decorators resolve the defining
    # module through sys.modules while the source prefix is being executed.
    # Register the isolated candidate module before exec so protected loading has
    # the same semantics as importing a normal train.py module.
    sys.modules[module.__name__] = module
    sys.path.insert(0, str(context.resolve()))
    exec(compile(source.split(marker, 1)[0], str(train_path), "exec"), module.__dict__)
    return module, train_path


def measure_checkpoint(*, context: pathlib.Path, candidate: str, checkpoint: pathlib.Path) -> dict[str, Any]:
    import torch
    from protected.inference_adapter import build_adapter, load_checkpoint_file, load_checkpoint_model

    module, _ = _load_candidate_definitions(context, candidate)
    payload = load_checkpoint_file(checkpoint)
    device = torch.device("cuda")
    model = load_checkpoint_model(module, payload, device)
    adapter = build_adapter(module, model)
    fp32_model = load_checkpoint_model(module, payload, device).float()
    fp32_adapter = build_adapter(module, fp32_model)
    tokenizer = module.Tokenizer.from_directory()
    input_ids = _fixed_input(tokenizer, torch, device)
    result = run_aggregated_stable_benchmark(
        adapter,
        lambda ids: model(ids),
        input_ids,
        torch,
        model=model,
        fp32_model=fp32_model,
        fp32_adapter=fp32_adapter,
    )
    result["checkpoint"] = str(checkpoint)
    result["candidate"] = candidate
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", required=True)
    parser.add_argument("--context", type=pathlib.Path, required=True)
    parser.add_argument("--candidate", default="train.py")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.protocol != PROTOCOL_VERSION:
        raise SystemExit(f"only {PROTOCOL_VERSION} is permitted")
    try:
        result = measure_checkpoint(
            context=args.context,
            candidate=args.candidate,
            checkpoint=pathlib.Path(args.checkpoint),
        )
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, sort_keys=True, default=str) + "\n")
        return 0
    except BaseException as exc:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps({"status": "error", "error": f"{type(exc).__name__}: {exc}"}, indent=2) + "\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
