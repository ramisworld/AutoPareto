"""Trusted A40-side entry point for the local Scientist bridge.

Only the orchestrator may invoke this module.  Its payload directory is expected
to contain exactly ``train.py`` and ``registered_metadata.json``; protected
``prepare.py`` and ``study_runtime.py`` are copied from the preinstalled A40
study checkout, never transferred from the Scientist context.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import secrets
import shutil
import subprocess
import sys
import tempfile
from typing import Any

from .bridge import REMOTE_RESULT_SCHEMA, sha256_file


DEFAULT_TRUSTED_ROOT = "/opt/autopareto_trusted"
DEFAULT_TRUSTED_STATE_ROOT = "/opt/autopareto_trusted/state"
DEFAULT_CANDIDATE_ROOT = "/workspace/autopareto_cleanroom_final"
DEFAULT_CANDIDATE_ATTEMPT_ROOT = "/opt/autopareto-candidate-attempts"


def _require_metadata(metadata: dict[str, Any], key: str) -> Any:
    if key not in metadata:
        raise ValueError(f"registered metadata is missing {key}")
    return metadata[key]


def _safe_payload(payload_dir: pathlib.Path) -> None:
    if not payload_dir.is_dir():
        raise ValueError("payload directory is not a directory")
    names = sorted(path.name for path in payload_dir.iterdir() if not path.name.startswith("."))
    if names != ["registered_metadata.json", "train.py"]:
        raise ValueError(f"payload must contain exactly train.py and registered_metadata.json: {names}")
    train = payload_dir / "train.py"
    if train.is_symlink() or not train.is_file():
        raise ValueError("payload train.py must be a regular file")


def _candidate_prepare_source(protected_prepare: pathlib.Path) -> str:
    """Stage the complete registered prepare.py dependency.

    Candidate-side validation remains forbidden by the candidate-process
    observer, which replaces ``evaluate_bpb`` after import.  Keeping the full
    module preserves the historical source dependency graph and avoids the
    incomplete temporary context that caused import/runtime drift.
    """
    source = protected_prepare.read_text()
    if not source.strip():
        raise ValueError("protected prepare.py is empty")
    return source


def execute(*, payload_dir: pathlib.Path, output: pathlib.Path, repository: pathlib.Path) -> dict[str, Any]:
    _safe_payload(payload_dir)
    trusted_root = pathlib.Path(
        os.environ.get("AUTOPARETO_TRUSTED_ROOT", str(repository))
    ).resolve(strict=True)
    trusted_state_root = pathlib.Path(
        os.environ.get("AUTOPARETO_TRUSTED_STATE_ROOT", DEFAULT_TRUSTED_STATE_ROOT)
    ).resolve()
    trusted_state_root.mkdir(mode=0o700, parents=True, exist_ok=True)
    output = output.resolve()
    if not output.is_relative_to(trusted_state_root):
        raise ValueError("trusted runner output must be persisted below AUTOPARETO_TRUSTED_STATE_ROOT")
    if trusted_root.stat().st_uid != 0 or trusted_root.stat().st_mode & 0o077:
        raise ValueError("trusted runner root must be root-owned and inaccessible to the candidate UID")
    metadata = json.loads((payload_dir / "registered_metadata.json").read_text())
    if metadata.get("schema") != "autopareto_a40_payload_v1":
        raise ValueError("unexpected registered payload schema")
    if sha256_file(payload_dir / "train.py") != _require_metadata(metadata, "candidate_source_after_sha256"):
        raise ValueError("candidate source hash does not match registered metadata")

    protected_prepare = trusted_root / "study/contracts_2026/historical_reference/baseline_source/prepare.py"
    study_runtime = trusted_root / "study/contracts_2026/study_runtime.py"
    if not protected_prepare.is_file() or not study_runtime.is_file():
        raise FileNotFoundError("preinstalled protected prepare.py or study_runtime.py is missing")
    registered_prepare_hash = metadata.get("protected_prepare_sha256")
    if registered_prepare_hash and sha256_file(protected_prepare) != registered_prepare_hash:
        raise ValueError("protected prepare.py hash does not match registered metadata")
    registered_runtime_hash = metadata.get("study_runtime_sha256")
    if registered_runtime_hash and sha256_file(study_runtime) != registered_runtime_hash:
        raise ValueError("study_runtime.py hash does not match registered metadata")

    attempt_root_base = pathlib.Path(
        os.environ.get("AUTOPARETO_CANDIDATE_ATTEMPT_ROOT", DEFAULT_CANDIDATE_ATTEMPT_ROOT)
    ).resolve()
    attempt_root_base.mkdir(mode=0o711, parents=True, exist_ok=True)
    attempt_root = attempt_root_base / f"{payload_dir.name}-{secrets.token_hex(12)}"
    attempt_root.mkdir(mode=0o711)
    # The payload directory and all trusted metadata stay outside the clean room.
    # Only the five registered Scientist-visible files are staged under the
    # candidate-visible root; the candidate output/checkpoint stays in its own
    # disposable directory and is copied to trusted state after verification.
    candidate_root = pathlib.Path(
        os.environ.get("AUTOPARETO_CANDIDATE_ROOT", DEFAULT_CANDIDATE_ROOT)
    ).resolve()
    context_root = pathlib.Path(
        os.environ.get("AUTOPARETO_CANDIDATE_CONTEXT_ROOT", "/opt/autopareto_candidate_contexts")
    ).resolve()
    context_root.mkdir(mode=0o755, parents=True, exist_ok=True)
    context = pathlib.Path(tempfile.mkdtemp(prefix=f"{payload_dir.name}-", dir=context_root))
    context.chmod(0o555)
    try:
        shutil.copy2(payload_dir / "train.py", context / "train.py")
        (context / "prepare.py").write_text(_candidate_prepare_source(protected_prepare))
        shutil.copy2(study_runtime, context / "study_runtime.py")
        # The trusted parent owns the context.  The candidate process receives
        # read-only copies; only the unique candidate-output directory is
        # writable by the dedicated non-root identity.
        context.chmod(0o555)
        for path in context.iterdir():
            path.chmod(0o555 if path.is_dir() else 0o444)
        candidate_output = attempt_root / "candidate-output"
        candidate_output.mkdir(mode=0o700)
        candidate_result = candidate_output / output.name
        command = [
            sys.executable,
            "-m",
            "study.contracts_2026.train_launcher",
            "--context",
            str(context),
            "--candidate",
            "train.py",
            "--contract",
            str(_require_metadata(metadata, "contract_id")),
            "--seed",
            str(_require_metadata(metadata, "training_seed")),
            "--output",
            str(candidate_result),
            "--execute",
        ]
        contract_parameters = metadata.get("contract_parameters", {})
        if contract_parameters.get("n_star") is not None:
            command.extend(["--n-star", str(contract_parameters["n_star"])])
        if metadata.get("process_log_sd") is not None:
            command.extend(["--process-log-sd", str(float(metadata["process_log_sd"]))])
        # Do not inherit pod credentials or campaign/history variables into the
        # candidate launcher.  The process boundary applies a second whitelist,
        # but sanitizing before the wrapper is still required defense in depth.
        inherited_names = (
            "PATH", "LD_LIBRARY_PATH", "CUDA_VISIBLE_DEVICES", "NVIDIA_VISIBLE_DEVICES",
            "CUDA_HOME", "VIRTUAL_ENV", "PYTHONNOUSERSITE",
        )
        child_env = {name: os.environ[name] for name in inherited_names if os.environ.get(name)}
        child_env.update({
            "HOME": str(context),
            "AUTOPARETO_REGISTERED_CACHE": os.environ.get(
                "AUTOPARETO_REGISTERED_CACHE",
                str(pathlib.Path(os.environ.get("AUTOPARETO_APPROVED_INPUT_ROOT", "/opt/autopareto_candidate_inputs")) / "cache" / "autoresearch"),
            ),
            "AUTOPARETO_STUDY_VENV": os.environ.get(
                "AUTOPARETO_STUDY_VENV",
                str(pathlib.Path(os.environ.get("AUTOPARETO_STUDY_VENV", str(repository / ".venv")))),
            ),
            "AUTOPARETO_TRUSTED_ROOT": str(trusted_root),
                "AUTOPARETO_CANDIDATE_ROOT": str(candidate_root),
            "AUTOPARETO_CANDIDATE_RUNTIME_ROOT": os.environ.get(
                "AUTOPARETO_CANDIDATE_RUNTIME_ROOT", "/opt/autopareto_candidate_runtime"
            ),
            "AUTOPARETO_CANDIDATE_INPUT_ROOT": os.environ.get(
                "AUTOPARETO_CANDIDATE_INPUT_ROOT", "/opt/autopareto_candidate_inputs/per_attempts"
            ),
            "AUTOPARETO_STUDY_ALLOW_EXECUTION": "1",
            "AUTOPARETO_REMOTE_SANDBOX": "1",
        })
        completed = subprocess.run(
            command,
            cwd=trusted_root,
            env=child_env,
            check=False,
        )
        if completed.returncode != 0 or not candidate_result.is_file():
            raise RuntimeError(f"protected A40 runner failed with return code {completed.returncode}")
        result = json.loads(candidate_result.read_text())
    finally:
        # Preserve the attempt-local checkpoint/timing artifacts for trusted
        # provenance.  The candidate cannot modify them after its process exits.
        context.chmod(0o555)
    # Persist a root-owned copy of the candidate result and all post-training
    # artifacts before returning it to the outer bridge.  The candidate-visible
    # attempt directory remains disposable and is never the authoritative store.
    trusted_attempt = trusted_state_root / "attempts" / attempt_root.name
    trusted_attempt.mkdir(mode=0o700, parents=True, exist_ok=True)
    persisted: dict[str, str] = {}
    checkpoint_source = pathlib.Path(str(result.get("checkpoint", ""))).resolve()
    expected_artifacts = [
        candidate_result,
        candidate_result.with_name(candidate_result.name + ".worker.json"),
        checkpoint_source,
        candidate_result.with_name(candidate_result.stem + ".inference.json"),
    ]
    for source in expected_artifacts:
        if source.parent != candidate_output:
            continue
        name = source.name
        if source.is_file():
            target = trusted_attempt / name
            shutil.copy2(source, target)
            target.chmod(0o400)
            persisted[name] = str(target)
    result.update(
        {
            "schema": REMOTE_RESULT_SCHEMA,
            "campaign_id": metadata["campaign_id"],
            "contract_id": metadata["contract_id"],
            "attempt": metadata["attempt_number"],
            "registered_metadata_sha256": hashlib.sha256(
                (json.dumps(metadata, sort_keys=True) + "\n").encode()
            ).hexdigest(),
            "trusted_persistence": {
                "root": str(trusted_state_root),
                "attempt": str(trusted_attempt),
                "artifacts": persisted,
            },
        }
    )
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--payload-dir", type=pathlib.Path, required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--repository", type=pathlib.Path, default=pathlib.Path(__file__).resolve().parents[2])
    return parser


if __name__ == "__main__":
    args = build_parser().parse_args()
    payload = execute(payload_dir=args.payload_dir.resolve(), output=args.output.resolve(), repository=args.repository.resolve())
    print(json.dumps(payload, sort_keys=True))
